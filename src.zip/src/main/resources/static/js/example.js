/* REGISTRO DE USUARIO */
function saveUser() {
    let name = $.trim($('name').val());
    let email = $.trim($('email').val());
    let password = $.trim($('password').val());
    let password_conf = $.trim($('password_conf').val());

    if (name != "" && email != "" && password != "" && password_conf != "") {
        if (password != password_conf) {
            alert("Claves no coinciden");
            $("#password_conf").focus();
        } else {
            $.ajax({
                url: 'www.google.com.co',
                data: JSON.stringify({
                    "email": email,
                    "password": password,
                    "name": name
                }),
                type: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                error: function(response) {
                    alert("Usuario no resgistrado")
                    console.log(response);
                },

                success: function(result) {
                    console.log(result);
                    if (result.id == null) {
                        alert("No se puede crear la cuenta");
                        $("#name").focus();
                        $("#email").focus();
                    } else {
                        alert("La cuenta se creo correctamente.");
                    }
                    $(':input').val(" ");
                    $('#name').focus();

                }

            });
        }
    }

    return false;
}

/* LOGIN USUARIO */

function login() {
    let email = $.trim($('email').val());
    let password = $.trim($('password').val());
    if (email != "" && password != "") {
        $.ajax({
            url: 'www.google.com.co' + email + password,
            contenType: 'application/json',
            dataType: 'json',
            error: function(response) {
                alert("Usuario no existe")
                console.log(response);
            },

            success: function(result) {
                console.log(result);
                if (result.id == null) {
                    alert("No existe un usuario con estos datos");
                } else {
                    alert("Se ha registrado correctamente" + result.name);
                }
                $(':input').val("");
                $('#email').focus();
            }

        });
        return false;
    }
}







/* function saveUser() {
    alert("ok");
    let name = $.trim($('name').val());
    let email = $.trim($('email').val());
    let password = $.trim($('password').val());
    let password_conf = $.trim($('password_conf').val());

    if (name != "" && email != "" && password != "" && password_conf != "") {
        if (password != password_conf) {
            alert("Claves no coinciden");
            $("#password_conf").focus();
        } else {
            $.ajax({
                url: 'http://localhost:8080/api/user/new',
                data: JSON.stringify({
                    "email": email,
                    "password": password,
                    "name": name
                }),
                type: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                error: function(response) {
                    alert("Usuario no resgistrado")
                    console.log(response);
                },

                success: function(result) {
                    console.log(result);
                    if (result.id == null) {
                        alert("No se puede crear la cuenta");
                        $("#name").focus();
                        $("#email").focus();
                    } else {
                        alert("La cuenta se creo correctamente.");
                    }
                    $(':input').val(" ");
                    $('#name').focus();

                }

            });
        }
    }

    return false;
} */



/* LOGIN USUARIO */

/* function login() {
    let email = $.trim($('email').val());
    let password = $.trim($('password').val());
    if (email != "" && password != "") {
        $.ajax({
            url: 'www.google.com.co' + email + password,
            contenType: 'application/json',
            dataType: 'json',
            error: function(response) {
                alert("Usuario no existe")
                console.log(response);
            },

            success: function(result) {
                console.log(result);
                if (result.id == null) {
                    alert("No existe un usuario con estos datos");
                } else {
                    alert("Se ha registrado correctamente" + result.name);
                }
                $(':input').val("");
                $('#email').focus();
            }

        });
        return false;
    }
} */



/* button.addEventListener('click', () => {
    let xhr = new XMLHttpRequest()

    xhr.open('GET', 'http://129.151.119.43:8080/api/user/all')

    xhr.addEventListener('load', (data) => {
        console.log(JSON.parse(data.target.response))
    })

    xhr.send()
}) */



/*  const sendData = (data) => {
            let xhr
            if (window.XMLHttpRequest) xhr = new XMLHttpRequest()
            else xhr = new ActiveXObject("Microsoft.XMLHTTP")


            xhr.open('POST', 'http://129.151.119.43:8080/api/user/new')
 const formData = new FormData(data)
            xhr.send(formData)

} */


/* const requestApi = () => {
    fetch('http://129.151.119.43:8080/api/user/all')
        .them(res => console.log(res))
} */


////////////////////////////////// mios ////////////////////



const form = document.getElementById('form');
const button = document.getElementById('submitButton');
const buttonDos = document.getElementById('submitRegister');
const msgAlert = document.getElementById('msgAlert');
let name = document.getElementById('name');
let email = document.getElementById('email');
let password = document.getElementById('password');
let passwordConf = document.getElementById('passwordConf');

const formIsValid = {
    email: false,
    password: false,

}



form.addEventListener('submit', (e) => {
    e.preventDefault()
    validateForm()
        /* sendData(form) */
        /* fetch('http://129.151.119.43:8080/api/user/all')
            .then(res => res.ok ? Promise.resolve(res) : Promise.reject(res))
            .them(res => res.json()) */

})


email.addEventListener('change', (e) => {
    if (e.target.value.trim().length > 0) formIsValid.email = true
    validateEmail()

})

password.addEventListener('change', (e) => {
    if (e.target.value.trim().length > 0) formIsValid.password = true

})

buttonDos.addEventListener('click', (e) => {
    saveUser()
})

const validateForm = () => {
    const formValues = Object.values(formIsValid)
    const valid = formValues.findIndex(value => value == false)
    if (valid == -1) form.submit()
    else msgAlert.innerHTML = '<span class="red">No se han rellenado los campos*</span>' //alert("El formulario no se ha rellanado")

}


const validateEmail = (email) => {
    const emailRegex = /^(([^<>()\[\]\\.,:\s@"]+(\.[^<>()\[\]\\.,:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    if (emailRegex.test(email)) console.log('email válido')
    else msgAlert.innerHTML = '<span class="red">Email incorrecto</span>' //console.log('email incorrecto')
}

const saveUser = () => {
    let name = $.trim($('name').val());
    let email = $.trim($('email').val());
    let password = $.trim($('password').val());
    let passwordConf = $.trim($('passwordConf').val());

    if (name != "" && email != "" && password != "" && passwordConf != "") {
        if (password != passwordConf) {
            alert("Claves no coinciden");
            $("#password_conf").focus();
        } else {
            $.ajax({
                url: 'www.google.com.co',
                data: JSON.stringify({
                    "email": email,
                    "password": password,
                    "name": name
                }),
                type: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                error: function(response) {
                    alert("Usuario no resgistrado")
                    console.log(response);
                },

                success: function(result) {
                    console.log(result);
                    if (result.id == null) {
                        alert("No se puede crear la cuenta");
                        $("#name").focus();
                        $("#email").focus();
                    } else {
                        alert("La cuenta se creo correctamente.");
                    }
                    $(':input').val(" ");
                    $('#name').focus();

                }

            });
        }
    }

    return false;

}