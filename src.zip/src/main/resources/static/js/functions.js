function saveUser() {
    let name = $('name').value;
    let email = $('email').val();
    let password = $('password').value;
    let passwordConf = $('passwordConf').value;


    console.log(name)
    console.log(email)
    console.log(password)
    console.log(passwordConf)

}