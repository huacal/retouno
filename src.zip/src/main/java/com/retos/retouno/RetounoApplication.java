package com.retos.retouno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetounoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetounoApplication.class, args);
	}

}
